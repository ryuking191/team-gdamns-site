GitHub Pages 公開手順（LINEで開けるリンク用）

1) GitHub でリポジトリを作成： team-gdamns-site
2) このフォルダ内のファイルをすべてアップロード（index.html, style.css, script.js, images/...）
3) Settings → Pages → Source: "Deploy from a branch"
   Branch: main / Folder: /(root) を選んで Save
4) 数十秒〜数分で公開されます：
   https://ryuking191.github.io/team-gdamns-site/

LINEで送るリンク：
https://ryuking191.github.io/team-gdamns-site/
